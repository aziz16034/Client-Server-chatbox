
import mysql.connector

mydb = mysql.connector.connect(host="localhost", user="root", passwd="12345", database="Connectivity")
mycursor= mydb.cursor()

mycursor.execute("Create table number( roll int(10) PRIMARY KEY AUTO_INCREMENT, URL varchar(255),Status varchar(255))");
#mycursor.execute("Create table number(  major  varchar(255), class  varchar(255))");

mycursor.execute("Show tables")

for y in mycursor:
    print(y)
