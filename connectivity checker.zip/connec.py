import socket
import mysql.connector


mydb = mysql.connector.connect(host="localhost", user="root", passwd="12345", database="Connectivity")
mycursor= mydb.cursor()


print("website connection checker")
website = input("please input website: ")

while website != 'Q':

    print("")
    print(socket.gethostbyname(website))
    if socket.gethostbyname(website) == "92.242.140.2":
        print("Website could be experiencing an issue/Doesn't exist")
        abcd ='Not Active'

    else:
        socket.gethostbyname(website)
        print("Website is operational!")
        print("")
        abcd ='Active'

    break

while website == 'Q':
 print("Thank you")







sqlform = "Insert into number(URL, Status) values(%s,%s)"

number = [(website, abcd)]
mycursor.executemany(sqlform, number)
mydb.commit()